package com.jh.afinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SearchingDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.searchingdetail);
    }
}